package com.nucleus.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.DAO.CustomerDAO;

import com.nucleus.model.Customer;

@Controller
public class ControllerCustomer
{ 
	@Autowired
	CustomerDAO customerDAO;
	
//***************************************** new user ******************************************************************************	
 @RequestMapping("/Menubar11")
 public String handler1()
 {
	
	return "Menubar1";
	 
 }
 @RequestMapping("/Checker11")
 public String handler12()
 {
	
	return "checker";
	 
 }
 
 
 @RequestMapping("/newuser")
 public ModelAndView handler2(Customer customer)
 {
	return new ModelAndView("NewUser");
	 
 }
 @RequestMapping("/submit")
 public String handler3(Customer customer)
 {
	 customerDAO.newUser(customer);
	return "success";
	 
 }
 
 
 //************************************* delete ***************************************************************************************
 
 @RequestMapping("/delete")
 public ModelAndView handler4(Customer customer)
 {
	
	return new ModelAndView("Deletec");
	
 }
 
 @RequestMapping("/submit2")
 
 public String handler5(@RequestParam("customerCode")String customerCode)
 {
	customerDAO.delete(customerCode);
	return ("delete11");
 }
 //*************************************** view ************************************************************************************
  
 @RequestMapping("/viewcon")
 public String handler6()
 {
	return ("  viewc");
	 
	
 }
 
 
@RequestMapping("/submit3")
public ModelAndView handler7(@RequestParam("customerCode")String customerCode)
{   
	
	Customer customer=customerDAO.view(customerCode);
	return new ModelAndView("view","customer",customer);
	 
	
}
 
 
//****************************************** view all **************************************************************************** 

@RequestMapping("/viewallcon")
public ModelAndView handler8(Customer customer)
{   
	
	List<Customer> list=customerDAO.viewAll();
	return new ModelAndView("viewallc","list",list);
	 
	
}
 
//********************************************* update *************************************************************************** 
 

@RequestMapping("/updatecon")
public String handler9(Customer customer)
{
	return "updatei";
}

@RequestMapping("/updatecustomer")
public ModelAndView handler10(@RequestParam("customerCode")String customerCode)
{   
    
	 
		Customer customer=customerDAO.viewUpdate(customerCode);

		return new ModelAndView("update1","customer",customer);
	
}


@RequestMapping("/update23")
public String handler11(Customer customer)
{   
	  
		customerDAO.Update(customer);
	    
		return "updaterecord1";
		
	
	
}



 
 
}
