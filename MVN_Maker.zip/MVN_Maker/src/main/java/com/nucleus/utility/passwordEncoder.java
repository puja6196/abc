package com.nucleus.utility;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class passwordEncoder 
{
	public static String encodePwd(String pwd)
	{
		BCryptPasswordEncoder bCryptPasswordEncoder =new BCryptPasswordEncoder();
		return bCryptPasswordEncoder.encode(pwd);
	}
	public static void main(String [] args)
	{
		System.out.println(encodePwd("user2"));
	}
}
