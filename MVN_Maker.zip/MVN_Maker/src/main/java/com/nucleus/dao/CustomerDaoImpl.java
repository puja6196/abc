package com.nucleus.dao;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nucleus.controller.Map;
import com.nucleus.domain.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao
{
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	//===================================================insert=====================================================
	@Override
	public void save(Customer customer) 
	{
		long millis=System.currentTimeMillis();
		Date date=new Date(millis);
		
		Object[] values={customer.getCustomerCode(),customer.getCustomerName(),customer.getCustomerAddress1(),
						customer.getCustomerAddress2(),customer.getCustomerPinCode(),customer.getEmailaddress(),
						customer.getContactNumber(),customer.getPrimaryContactPerson(),customer.getRecordStatus(),
						customer.getActiveInactiveFlag(),date,"pranjali",customer.getModifiedDate(),
						customer.getModifiedBy()};
		
		jdbcTemplate.update("insert into pranjalicustomertable1230 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",values);
	}
	//========================================delete================================================================
	
	@Override
	public void delete(String customercode) 
	{
		jdbcTemplate.update("delete from pranjalicustomertable1230 where customercode=?",customercode);
	}
	
	//==============================================view all===================================================================
	@Override
	public List<Customer> show() 
	{
		List<Customer> customer0=(List<Customer>) jdbcTemplate.query("select * from pranjalicustomertable1230",new Map());
		return customer0;
	}
	
	//============================================view================================================================================================
	@Override
	public Customer showRecord(Customer customer)
	{
		Object customers[]={customer.getCustomerCode()};
		Customer u= (Customer) jdbcTemplate.queryForObject("select * from  pranjalicustomertable1230 where customercode=?",customers,new Map());
		return u;		
	}
	
	//==================================================update============================================================================
	@Override
	public Customer updateRecord(Customer customer) 
	{
		long millis=System.currentTimeMillis();
		Date date=new Date(millis);
		
		Object[] values0={customer.getCustomerName(),customer.getCustomerAddress1(),
						customer.getCustomerAddress2(),customer.getCustomerPinCode(),customer.getEmailaddress(),
						customer.getContactNumber(),customer.getPrimaryContactPerson(),customer.getRecordStatus(),
						customer.getActiveInactiveFlag(),date,"pranjali",customer.getCustomerCode()};
		
		jdbcTemplate.update(
				"update pranjalicustomertable1230 set CustomerName=?,CustomerAddress1=?,CustomerAddress2=?, CustomerPinCode=?,Emailaddress=?,ContactNumber=?, PrimaryContactPerson=?,RecordStatus=?, ActiveInactiveFlag=?,ModifiedDate=?,ModifiedBy=? where customercode=?",
				values0);
		return customer;
	}

}
