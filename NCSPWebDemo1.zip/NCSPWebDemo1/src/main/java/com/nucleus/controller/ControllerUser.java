package com.nucleus.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ControllerUser
{  
	@RequestMapping("/login")
	public String handler1()
	{
		return "login1";
		
		
	}
	
	@RequestMapping("/loginfailure")
	public ModelAndView handler2()
	{
		return new ModelAndView("login1","error","Bad Credentials");
		
		
	}
	@RequestMapping("/accessdenied")
	public String handler3()
	{
		return "accessdenied1";
		
		
		
	}
	@RequestMapping("/Logout")
	public String handler5()
	{
		return "logout1";
		
		
	}
	@RequestMapping("/defaultpage")
	public String handler4(HttpServletRequest request)
	{
		String targeturl=null;
		if(request.isUserInRole("ROLE_MAKER"))
			targeturl="redirect:/Menubar11";
		else
		if(request.isUserInRole("ROLE_CHECKER"))
			targeturl="redirect:/Checker11";
		
		return targeturl;
		
		
		
	}
 
}
