package com.nucleus.Controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.model.Domain.Customer;

@Controller
public class LoginController 
{
	@RequestMapping("/accdenied")
	public String RequestHandler1()
	{
		return "accessdenied";
	}
	
	@RequestMapping("/login")
	public String RequestHandler2()
	{
		return "login";
	}
	
	@RequestMapping("/loginfailure")
	public ModelAndView Requesthandler3()
	{
		return new ModelAndView("login","msg","bad credentials");
	}
	@RequestMapping("/logout")
	public String RequestHandler3()
	{
		return "Logout";
	}
	

	@RequestMapping("/defaultpage")
	public String RequestHandler4(HttpServletRequest request)
	{
		String targetUrl=null;
		if(request.isUserInRole("ROLE_MAKER"))
			targetUrl="redirect:/makerr";
		else
		if(request.isUserInRole("ROLE_CHECKER"))
			targetUrl="redirect:/checkerr";
		else 
			targetUrl="redirect:/";
		
		return targetUrl;
			
	}


	
}

