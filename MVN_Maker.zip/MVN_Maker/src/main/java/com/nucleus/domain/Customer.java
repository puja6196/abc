package com.nucleus.domain;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.NumberFormat;

public class Customer implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		
	@NotNull	
	@Pattern(regexp ="^[0-9a-zA-Z]*$")
	@Length(min=1,max=10)
	String customerCode; 
	@NotNull
	@Pattern(regexp ="^[0-9a-zA-Z]*$")
	@Length(min=1,max=10)
	private String customerName ;
	@NotNull
	private String customerAddress1 ;
	private String customerAddress2;
	@NotNull
	//@NumberFormat
	@Pattern(regexp ="^[0-9]*$")
	@Length(min=6,max=6)
	private String customerPinCode ;
	@Email
	private String emailaddress;
	//@NumberFormat
	@Pattern(regexp ="^[0-9]*$")
	@Length(min=10,max=10)
	private String contactNumber; 
	@NotNull
	private String primaryContactPerson;	
	private String recordStatus; 	
	private String activeInactiveFlag ;	
	@DateTimeFormat
	private String createDate; 
	private String createdBy ;
	@DateTimeFormat
	private String modifiedDate ;
	private String modifiedBy ;
	
	
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress1() {
		return customerAddress1;
	}
	public void setCustomerAddress1(String customerAddress1) {
		this.customerAddress1 = customerAddress1;
	}
	public String getCustomerAddress2() {
		return customerAddress2;
	}
	public void setCustomerAddress2(String customerAddress2) {
		this.customerAddress2 = customerAddress2;
	}
	public String getCustomerPinCode() {
		return customerPinCode;
	}
	public void setCustomerPinCode(String customerPinCode) {
		this.customerPinCode = customerPinCode;
	}
	public String getEmailaddress() {
		return emailaddress;
	}
	public void setEmailaddress(String emailaddress) {
		this.emailaddress = emailaddress;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getPrimaryContactPerson() {
		return primaryContactPerson;
	}
	public void setPrimaryContactPerson(String primaryContactPerson) {
		this.primaryContactPerson = primaryContactPerson;
	}
	public String getRecordStatus() {
		return recordStatus;
	}
	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}
	public String getActiveInactiveFlag() {
		return activeInactiveFlag;
	}
	public void setActiveInactiveFlag(String activeInactiveFlag) {
		this.activeInactiveFlag = activeInactiveFlag;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
}
