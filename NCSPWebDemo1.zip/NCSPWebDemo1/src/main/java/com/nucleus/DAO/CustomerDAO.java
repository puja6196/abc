package com.nucleus.DAO;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.nucleus.model.Customer;
@Repository
public interface CustomerDAO
{
	public void newUser(Customer customer);
	
	public void delete(String customerCode);
	
	public List<Customer> viewAll();
	public Customer viewUpdate(String usercode);
	public	 void Update(Customer customer);
	public Customer view(String customerCode);
	
}
