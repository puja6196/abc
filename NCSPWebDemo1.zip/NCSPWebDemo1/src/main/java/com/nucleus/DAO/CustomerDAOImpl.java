package com.nucleus.DAO;

import java.sql.Date;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import com.nucleus.mapper.Mapper;
import com.nucleus.model.Customer;

@Repository
public class CustomerDAOImpl implements CustomerDAO
{ 	@Autowired
	JdbcTemplate jdbcTemplate;
long millis=System.currentTimeMillis();
	Date date=new Date(millis);

//********************************************* new user ********************************************************
	public void newUser(Customer customer)
	{ 
		 Object[] values={customer.getCustomerCode(),customer.getCustomerName(),customer.getCustomerAddress1(),customer.getCustomerAddress2(),customer.getCustomerPinCode(),customer.getEmailAddress(),customer.getContactNumber(),customer.getPrimaryContactPerson(),customer.getRecordStatus(),customer.getActiveInactiveFlag(),date,"puja",customer.getModifiedDate(),customer.getModifiedBy()} ;                                                                                                                                                                                                                                                                                                                                                                                                               
		 String sql="insert into pranjalicustomertable1230 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		 jdbcTemplate.update(sql,values);
		
	}
	//****************************************
	@Override
	public Customer view(String customerCode)
	{
		
          Object[] value={customerCode};
		  String sql = "SELECT * FROM pranjalicustomertable1230 where  customerCode=?";
		  return jdbcTemplate.queryForObject(sql,value, new BeanPropertyRowMapper<Customer>(Customer.class));
	 
	}
	// return jdbcTemplate.queryForObject(sql,new BeanPropertyRowMapper<Customer>(Customer.class));
	//******************************** delete ***********************************************************************
	@Override
	public void delete(String customerCode) 
	{
	 
     String sql="delete from pranjalicustomertable1230 where customerCode=?";
     jdbcTemplate.update(sql, customerCode);
		
	}
	//*************************************************************************************************************
	@Override
	public List<Customer> viewAll()
	{
		String sql="select * from pranjalicustomertable1230 ";
		return jdbcTemplate.query(sql, new Mapper());

		
	}
	
	//**************************************************************************************************************
	@Override
	public Customer viewUpdate(String customerCode)
	{ String sql = "SELECT * FROM pranjalicustomertable1230 where  customerCode=?";
	
	  Object[] value={customerCode};
	  return jdbcTemplate.queryForObject(sql, value, new BeanPropertyRowMapper<Customer>(Customer.class));

	
	}
	
	//****************************************************************************************************************
	@Override
	public void Update(Customer customer)
	{
		
	
		Object[] values={customer.getCustomerName(),customer.getCustomerAddress1(),customer.getCustomerAddress2(),customer.getCustomerPinCode(),customer.getEmailAddress(),customer.getContactNumber(),customer.getPrimaryContactPerson(),customer.getRecordStatus(),customer.getActiveInactiveFlag(),date,"sadiya",customer.getModifiedDate(),customer.getModifiedBy(),customer.getCustomerCode()};
		jdbcTemplate.update("update pranjalicustomertable1230 set customerName=?,customerAddress1=?,customerAddress2=?,customerPinCode=?,emailAddress=?,contactNumber=?,primaryContactPerson=?,recordStatus=?,activeInactiveFlag=?,createDate=?,createdBy=?,modifiedDate=?,modifiedBy=? where customerCode=?",values);
		
	}
	
	
	
}
