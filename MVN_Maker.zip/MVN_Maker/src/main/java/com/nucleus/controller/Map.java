package com.nucleus.controller;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nucleus.domain.Customer;

public class Map implements RowMapper<Customer>
{

	@Override
	public Customer mapRow(ResultSet rs, int rows) throws SQLException
	{
		Customer customer=new Customer();
		customer.setCustomerCode(rs.getString(1));
		customer.setCustomerName(rs.getString(2));
		customer.setCustomerAddress1(rs.getString(3));
		customer.setCustomerAddress2(rs.getString(4));
		customer.setCustomerPinCode(rs.getString(5));
		customer.setEmailaddress(rs.getString(6));
		customer.setContactNumber(rs.getString(7));
		customer.setPrimaryContactPerson(rs.getString(8));
		customer.setRecordStatus(rs.getString(9));
		customer.setActiveInactiveFlag(rs.getString(10));
		customer.setCreateDate(rs.getString(11));
		customer.setCreatedBy(rs.getString(12));
		customer.setModifiedDate(rs.getString(13));
		customer.setModifiedBy(rs.getString(14));
		return customer;
	}

}
