package com.nucleus.model.DAO;



import java.util.List;

import com.nucleus.model.Domain.Customer;




public interface CustomerDAO {
	
		public void save(Customer customer);
		public Customer update( Customer customer);
		public Customer viewUpdate(String Customer_Code);
		public void delete(String Customer_Code);
		public Customer view(String Customer_Code);
		public List<Customer> view_all();
		

		
}