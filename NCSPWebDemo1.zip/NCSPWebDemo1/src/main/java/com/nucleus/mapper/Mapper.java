package com.nucleus.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nucleus.model.Customer;

public class Mapper implements RowMapper<Customer>  
{
		   public Customer mapRow(ResultSet rs, int rowNum) throws SQLException 
		   {
			   Customer customer = new Customer();
			   customer.setCustomerCode(rs.getString("customerCode"));
			   customer.setCustomerName(rs.getString("customerName"));
			   customer.setCustomerAddress1(rs.getString("customerAddress1"));
			   customer.setCustomerAddress2(rs.getString("customerAddress2"));
			   customer.setCustomerPinCode(rs.getString("customerPinCode"));
			   customer.setEmailAddress(rs.getString("emailAddress"));
			   customer.setContactNumber(rs.getString("contactNumber"));
			   customer.setPrimaryContactPerson(rs.getString("primaryContactPerson"));
			   customer.setRecordStatus(rs.getString("recordStatus"));
			   customer.setActiveInactiveFlag(rs.getString("activeInactiveFlag"));
			   customer.setCreateDate(rs.getString("createDate"));
			   customer.setCreatedBy(rs.getString("createdBy"));
			   customer.setModifiedDate(rs.getString("modifiedDate"));
			   customer.setModifiedBy(rs.getString("modifiedBy"));
		      return customer;
		   }

}
