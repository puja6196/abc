package com.nucleus.Controller;

import com.nucleus.model.DAO.CustomerDAO;
import com.nucleus.model.Domain.*;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;



@Controller
public class ControllerOne 
{   
	
	@Autowired
	CustomerDAO customerDAO;
	/*@RequestMapping("/welcome")
	public String handler2(Customer customer)
   {
		return "Maker";
	}*/
	
	@RequestMapping("/makerr")
	public String handler2()
	{
		return "Maker";
	}
	
	@RequestMapping("/checkerr")
	public String handler11()
	{
		return "Checker";
	}
	
	@RequestMapping("/NewUser11")
	public ModelAndView handler4(Customer customer)
	{
		return new ModelAndView("NewUser1");
	}
 
	@RequestMapping("/submit")
	public ModelAndView handler3(@Valid Customer customer,BindingResult result)
	{
		if(result.hasErrors())
		{
			return new ModelAndView("NewUser1");
		}
		customerDAO.save(customer);
		return new ModelAndView("success");
	}
//-------------------------------------------------------------
	
	@RequestMapping("/Delete1")
	public ModelAndView handler5(Customer customer)
	{
		return new ModelAndView("dlt");
	}
	
	
	@RequestMapping("/delete1")
	public ModelAndView handler5(@RequestParam("Customer_Code")String customer_Code)
	{
		customerDAO.delete(customer_Code);
		return new ModelAndView("deleted");
	}
	//------------------------------------
	@RequestMapping("/view")
	public ModelAndView handler6(Customer customer)
	{
		return new ModelAndView( "view1");
	}
	
	
	@RequestMapping("/viewbook")
	public ModelAndView handler7(@RequestParam("Customer_Code")String customer_Code)
	{   
		Customer customer= customerDAO.view(customer_Code);
		return new ModelAndView("viewcust","customer",customer);
	}
	//-------------------------------------------
	@RequestMapping("/Update")
	public String handler8(Customer customer)
	{
		return "Update1";
	}
	
	@RequestMapping("/Update12")
	public ModelAndView handler9(@RequestParam("Customer_Code")String customer_Code)
	{   
	    
		Customer customer=customerDAO.viewUpdate(customer_Code);
	
		return new ModelAndView("Update2","customer",customer);
		
	}
	
	
   @RequestMapping("/updatebook1")
   public String handler10(Customer customer)
	{   
	    
	   customerDAO.update(customer);
	    return "updateresult";
		
	}
   
   //------------------------------------------------
   @RequestMapping("/viewall")
	
	public ModelAndView handler7()
	{   
		 List<Customer> list= customerDAO.view_all();
		return new ModelAndView("ViewAll","list",list);
	}
	

}
